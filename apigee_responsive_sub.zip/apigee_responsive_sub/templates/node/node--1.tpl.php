<?php

/**
 * This is node-1 which is supposed to be blank
 */