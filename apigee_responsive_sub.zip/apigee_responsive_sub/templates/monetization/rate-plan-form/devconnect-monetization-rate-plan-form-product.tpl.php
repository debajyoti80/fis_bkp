<div class="rate-plan-form-product-wrapper">
  <div class="rate-plan-form-product-label"><label>Products:</label></div>
  <div class="rate-plan-form-product-list"><?php print implode(t(', '), $products); ?></div>
</div>
<div class="clearfix"></div>
<hr>
