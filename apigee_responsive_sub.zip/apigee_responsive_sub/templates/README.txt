This folder is where you should place all your overriding template files. By
default, the Bootstrap base theme provides all the necessary template files in
various folders inside of sites/*/themes/bootstrap/theme. For example, the
page.tpl.php template file is located at
sites/*/themes/bootstrap/theme/system/page.tpl.php. To override any of these
files, copy them from the Bootstrap base theme and place them in here.
