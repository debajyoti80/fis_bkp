var $ = jQuery.noConflict();

 
 $(window).scroll(function() {
	if ($(".navbar").offset().top > 100) {
		if ($(window).width() > 767) {
			$(".navbar").addClass("navbar-fixed-top");
			$(".navbar").addClass("top-nav-collapse");
		} else {
			$(".navbar").removeClass("navbar-fixed-top");
			$(".navbar").removeClass("top-nav-collapse");
		}
	} else {
		$(".navbar-fixed-top").removeClass("top-nav-collapse");
	}
});


jQuery(document).ready(function(){
		
			//Accordion Nav
			jQuery('.mainNav').navAccordion({
				expandButtonText: '<span class="glyphicon glyphicon-chevron-down"></span>',  
				collapseButtonText: '<span class="glyphicon glyphicon-chevron-up"></span>'
			}, 
			function(){
				console.log('Callback')
			});
			
		});