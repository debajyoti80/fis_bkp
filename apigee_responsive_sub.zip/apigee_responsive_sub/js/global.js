(function ($) {
    Drupal.behaviors.apigee_responsive = {
        attach: function (context, settings) {
            $('div.modal ul.openid-links li.user-link').hide();
            $('div.modal a[href="#openid-login"]').click(function() {
                $('div.modal div.apigee-responsive-openidhide').show();
            });

            $('li.dropdown').mouseover(function() {
                $(this).addClass('open');
            });

            $('li.dropdown').mouseout(function() {
                $(this).removeClass('open');
            });

            // Load the app delete form in a modal.
            $('.apigee-modal-link-delete a').click(function() {
                var hrefLocation = $(this).attr('href');
                var identifier = $(this).attr('data-target');

                // Open the empty modal.
                $(identifier).modal();
                if (($(identifier + ' .modal-body #devconnect_developer_application_delete').length == 0)) {
                    $(identifier + ' .modal-body').html('<p class="load-indicator" style="display:none;">' +
                        '<span class="label label-success" style="padding:5px;">Loading...</span></p>');
                    apigeePulsateForever(identifier + ' .modal-body .load-indicator');
                }

                // Load the page fragment (#devconnect_developer_application_delete) via an AJAX call.
                $(identifier + ' .modal-body').load(hrefLocation + ' #devconnect_developer_application_delete', function() {
                    if (!($(identifier + ' .modal-body #devconnect_developer_application_delete').length == 0)) {
                        $(this).remove('.load-indicator');
                    }
                });
                return false;
            });

            // Load the app edit form in a modal.
            $('.apigee-modal-link-edit a').click(function() {
                var hrefLocation = $(this).attr('href');
                var identifier = $(this).attr('data-target');

                // Open the empty modal.
                $(identifier).modal();
                if (($(identifier + ' .modal-body #devconnect-developer-apps-edit-form').length == 0)) {
                    $(identifier + ' .modal-body').html('<p class="load-indicator" style="display:none;">' +
                        '<span class="label label-success" style="padding:5px;">Loading...</span></p>');
                    apigeePulsateForever(identifier + ' .modal-body .load-indicator');

                    // Load the page fragment (#devconnect-developer-apps-edit-form) via an AJAX call.
                    $(identifier + ' .modal-body').load(hrefLocation + ' #devconnect-developer-apps-edit-form', function() {
                        if (!($(identifier + ' .modal-body #devconnect_developer_application_delete').length == 0)) {
                            $(this).remove('.load-indicator');
                        }
                        if (Drupal.settings.devconnect_developer_apps.selectlist == 'true'){
                            var selectItem = identifier + ' .selectlist-item';
                            $(identifier + ' select#api_product').attr('title', 'Select an API Product');

                            var sl = $(identifier + ' select#api_product').selectList({
                                instance: true,
                                clickRemove: false,
                                onAdd: function (select, value, text) {
                                    $(selectItem + ':last').append('<span style="margin-top:5px;" ' +
                                        'class="btn btn-primary pull-right remove-product">Remove</span>');
                                }
                            });

                            $('.selectlist-list').on('click', '.remove-product', function(event) {
                                sl.remove($(this).parent().data('value'));
                            });

                            $(selectItem).append('<span style="margin-top:5px;" ' +
                                'class="btn btn-primary pull-right remove-product">Remove</span>');
                        }
                    });
                }
                return false;
            });

            function apigeePulsateForever(elem) {
                $(elem).fadeTo(500, 1.0);
                $(elem).fadeTo(500, 0.1, function() {
                    apigeePulsateForever(elem);
                });
            }
        }
    };
	   //This is use to chnage forum to communities
	   $(document).ready(function(){
		if($('.fispage_title').text().trim()=='Forums'){
        $('.fispage_title').text('Communities');
        $('.panel-heading h3').text('Communities');
		}
		//Fixing Footer for all pages
		var i = $('.footer').html();
        $('.footer').remove();
		$('body').append('<footer class="footer footer-fixed-bottom">'+i+'</footer>');
		//Fixing search pagel ui landing page
		$('.search-container-copy form').addClass('search-form clearfix navbar-search pull-right navbar-search pull-right');
		
		//This portion of the code for displaying breadcrumbs in the page
		 /*$('.fispage_title').before("");
		 var pageURL = $(location).attr("href");
		 var res = pageURL.split("/");
		 var totallen = res.length;
		 var bLink="";
		 if(res.length > 2){
			 if((res.length>4)&&(res[totallen-1] =='apis')){
				 
				bLink= '<a href="'+res[0]+'//'+res[2]+'">Home</a> >> <a href="'+res[0]+'/'+res[totallen-1]+'">apis</a> >> <a href="'+pageURL+'">'+res[3]+'</a>';
			 }else if((totallen==7)&&((res[5] !=''))){
				
				 bLink= '<a href="'+res[0]+'//'+res[2]+'">Home</a> >> <a href="'+res[0]+'/'+res[4]+'">apis</a> >> <a href="'+res[0]+'/'+res[3]+'/'+res[4]+'">'+res[3]+'</a>';
			 }else{
				
			 var j=2;
			 var links = res[2];
			 for(i=3;i<=res.length;i++){
				 var linkTitle = res[j];
				 if(j == 2){
					 linkTitle = 'Home';
				 }
				 bLink= bLink+' <a href="'+res[0]+'//'+links+'">'+linkTitle+'</a> >> ';
				 links = links+'/'+res[j+1];
				 //console.log(bLink);
				 j++;
				 
			 }
			 bLink=bLink.slice(0, -3);
			}
			 
			 $('.fispage_title').before(bLink);
		 }*/
		 
		
});

})(jQuery);
